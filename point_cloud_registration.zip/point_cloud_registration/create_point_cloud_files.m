clear;clc


B=load('B.mat');
B=B.B;
trus_p=load('trus_p.mat');
trus_p=trus_p.trus_p;
trus_p=[trus_p; ones(1,size(trus_p,2))];

abdominal_p=load('abdominal_p.mat');
abdominal_p=abdominal_p.p ;
abdominal_p=[abdominal_p; ones(1,size(abdominal_p,2))];

angle=load('trus_angle.mat');
angle=angle.angle;
angle(3)=[];%bad point

% % Convert the rotation angles from degrees to radians
% rotationAngles = deg2rad(angle);

% Create an array of 4x4 transformation matrices for each rotation angle
transformations = zeros(4, 4, 6); % pre-allocate a 4x4x6 array
for i = 1:numel(angle)
    Xt(:, :, i) = [rotx(angle(i)) zeros(3, 1); 0 0 0 1];
end


X=[ -0.0808    0.9286    0.3622  249.4470;
   -0.9121    0.0776   -0.4026   -2.6181;
   -0.4020   -0.3628    0.8407    7.0358;
         0         0         0    1.0000];


%find the points coordinates in robot base
for i=1:size(abdominal_p,2)
points_in_robot_base(:,i)=B(:,:,i)*X*abdominal_p(:,i);
end

%find the points coordinates with respect to trus.
for i=1:size(trus_p,2)
points_in_trus(:,i)=Xt(:,:,i)*trus_p(:,i);
end

%remove the last row
points_in_trus(end,:)=[];
points_in_robot_base(end,:)=[];



% % Create point cloud object
%   points_in_robot_baseCloud = pointCloud(points_in_robot_base');
%   points_in_trusCloud = pointCloud(points_in_trus');
% 
% % Save point cloud to a PCD file
% filename = 'points_in_robot_baseCloud.pcd';
% pcwrite(points_in_robot_baseCloud, filename);
% % Save point cloud to a PCD file
% filename = 'points_in_trusCloud.pcd';
% pcwrite(points_in_trusCloud, filename);


A=[rand(2) rand(2) rand(2) rand(2) rand(2) rand(2) rand(2) rand(2) rand(2) ;zeros(1,18)]'*rotz(53)*roty(56);
B=A*rotx(90)*rotz(24)*roty(45)+[rand rand rand];

% Create point cloud object
  ACloud = pointCloud(A);
 BCloud = pointCloud(B);

% Save point cloud to a PCD file
filename = 'A.pcd';
pcwrite(ACloud, filename);
% Save point cloud to a PCD file
filename = 'B.pcd';
pcwrite(BCloud, filename);

