

X=[ -0.0808    0.9286    0.3622  249.4470;
   -0.9121    0.0776   -0.4026   -2.6181;
   -0.4020   -0.3628    0.8407    7.0358;
         0         0         0    1.0000];
X(1:3,4)=X(1:3,4)/1000;

z=[rotz(180) zeros(3, 1); 0 0 0 1];

transformation=load('transformation.mat');
transformation=transformation.transformation;
 transformation(1:3,4)=transformation(1:3,4)/1000;

Xt=[rotx(90) zeros(3, 1); 0 0 0 1];


new=inv(transformation)*Xt*z*inv(X)


R = new(1:3,1:3);
roll = atan2(R(3,2), R(3,3));
pitch = atan2(-R(3,1), sqrt(R(3,2)^2 + R(3,3)^2));
yaw = atan2(R(2,1), R(1,1));

inv(transformation)*Xt*z*inv(X);


% translate the quaternion to rotation matrix

quaterion=[0.31 0.507 0.763 -0.254];
quaterion=[quaterion(:,4) quaterion(:,1) quaterion(:,2) quaterion(:,3)];% because Ros publish q as qx,qy,qz,qw 
R1=quat2rotm(quaterion);

R2=R1*X(1:3,1:3)

% 
% [-0.253 0.762 -0.505 -0.316]
% 
% 
R3=inv(transformation)*Xt*z


eul = rotm2eul(R2)
eul2 = rotm2eul(R3(1:3,1:3))


%% cheating method
clear
x=[   -0.0441    0.9571   -0.2865  252.9066;
    0.7949    0.2073    0.5703   -1.7710;
    0.6051   -0.2026   -0.7700    7.6861;
         0         0         0    1.0000];

z=[rotz(180) zeros(3, 1); 0 0 0 1];

Xt=[rotx(90) zeros(3, 1); 0 0 0 1];

trans=[0.054 0.231 0.576]*1000;

Rqq=quat2rotm([0.471 0.794 -0.257 0.287]); %swithched the order already

xqq=[Rqq trans';[0 0 0 1]];

cheater=xqq*x*z*inv(Xt)   
