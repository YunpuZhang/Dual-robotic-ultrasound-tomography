%validation test
clear;clc
load('transformation.mat');

R=rotx(pi/2);

point=[0;500;0;1];

T1=[eye(3) [0;-500;0];0 0 0 1];

xt=[R [0;0;0];0 0 0 1];
inv(T1)*inv(xt)*inv(transformation) 




E = [R, [0;-500;0];zeros(1,3), 1];

inv(E)*inv(transformation)

