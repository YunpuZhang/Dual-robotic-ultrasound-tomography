  clear;close all;clc

%% read B data from text file
Bdata = importdata('robot_pose_and_trus_angle.txt');
rot_cells = Bdata(strncmp(Bdata,'- Rotation',10));
trans_cells = Bdata(strncmp(Bdata,'- Translation',13)); %convert to mm


% Initialize a 4x50 matrix to hold the rotation values
quaterion = zeros(size(rot_cells,1),4);
translationMatrix= zeros(3, size(trans_cells,1));

for i=1:size(rot_cells,1)
% Extract the numerical values using regex and str2double
rotationValues = str2double(regexp(rot_cells{i}, '[-+]?[0-9]*\.?[0-9]+', 'match'));
translationValues = str2double(regexp(trans_cells{i}, '[-+]?[0-9]*\.?[0-9]+', 'match'))*1000;
% Save the values in the corresponding column of the  matrix
quaterion(i,:) = rotationValues;
translationMatrix(:, i) = translationValues;
end

%% translate the quaternion to rotation matrix
quaterion=[quaterion(:,4) quaterion(:,1) quaterion(:,2) quaterion(:,3)];% because Ros publish q as qx,qy,qz,qw 
R=quat2rotm(quaterion);

%% get B in Bxp
% Initialize a 4x4xsize(rot_cells,1) matrix to hold the transformation matrices
B = zeros(4, 4, size(rot_cells,1));

% Loop over each slice along the third dimension of the rotation matrix and translational vector
for i = 1:size(R, 3)
    % Concatenate the rotation matrix and translational vector for this slice
    B(:,:,i) = [R(:,:,i), translationMatrix(:,i); 0, 0, 0, 1];
end

%% get RF DATA 
% Open the file for reading
fid = fopen('abdominal_p.txt', 'r');

% Initialize variables to store the data
data = zeros(0, 2);
idx = 1;

% Read each line of the file and process it
tline = fgetl(fid);
while ischar(tline)
    % Split the line into tokens separated by whitespace
    tokens = strsplit(tline);
    
    % Check if the line contains "bad"
    if strcmp(tokens{1}, 'bad')
        % If it does, record zero in the data array
        data(idx, :) = [0 0];
    else
        % If it doesn't, record the two numbers in the data array
        data(idx, :) = [str2double(tokens{1}) str2double(tokens{2})];
    end
    
    % Increment the index counter
    idx = idx + 1;
    
    % Read the next line of the file
    tline = fgetl(fid);
end

% Close the file
fclose(fid);


%% remove the bad points from B and RFdata
% find the position of the bad points
% Find the row indices where the first column is zero
bad_indices = find(data(:, 1) == 0);

data(bad_indices,:)=[];

% Create a logical index of matrices to be kept
keep_indices = true(1, size(B, 3));
keep_indices(bad_indices) = false;
% Remove the matrices at the bad_indices along the third dimension
B = B(:,:,keep_indices);


%% define the test parameters(size of the RF data).
sample_frequency=6.6e6;
depth_mm=29;
width_mm=60;
RF=zeros(1648,256); %get the RF data size from RP read\run me


%% calculte trus p
for i=1:size(data,1)
x(i)=(data(i,1)-(size(RF,2)/2))*(width_mm/size(RF,2)); % Find x relative to center of image
y(i)=data(i,2)*(depth_mm/size(RF,1)); %  

%y1(i)=data(i,2)*(1/sample_frequency)*1500/2*1000; %学长方法？？
p(i,:)=[x(i) y(i)];
end
p=[p  zeros(size(x))']';

 
%% Helper functions

% Translational error between two 4x4 frames
function error=tranerror(X1, X2)
    error=norm(X1(1:3,4)-X2(1:3,4));
end

% Rotational error between two frames
function error=roterror(X1,X2)
    error=norm(so3_vec(logm((X1(1:3,1:3)'*X2(1:3,1:3)))));
end

%Function to vectorize or hat an element in so(3)
function g = so3_vec(X)
    if (size(X,2)==3)
        %If input is skew-sym change to vector
        g = [-X(2,3); X(1,3); -X(1,2)];
    else
        %If input is vector change to skew-sym
        g = [0      -X(3)	 X(2)
             X(3)    0      -X(1)
            -X(2)    X(1)    0   ];
    end
end

%Function to vectorize or hat an element of se(3)
function g = se3_vec(X)
    if (size(X,2)==4)
        %If input is skew-sym change to vector
        g = [-X(2,3); X(1,3); -X(1,2); X(1,4); X(2,4); X(3,4)];
    else
        %If input is vector change to skew-sym
        g = [0      -X(3)	 X(2)	 X(4)
             X(3)    0      -X(1)    X(5)
            -X(2)    X(1)    0       X(6)
            0        0       0       0   ];
    end
end
