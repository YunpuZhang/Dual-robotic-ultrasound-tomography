clear;close all;clc


%% get rotation angle of trus
angle_data = importdata('robot_pose_and_trus_angle.txt');
myCellArray = angle_data(strncmp(angle_data,'TRUS:',5))';

% Use string manipulation functions to extract the numeric value from each string
 angle = zeros(6, 1); % pre-allocate a 6x1 matrix to store the extracted values
for i = 1:numel(myCellArray)
    match = regexp(myCellArray{i}, 'TRUS:(\d+\.\d+)', 'tokens');
    angle(i) = str2double(match{1}{1});
end



%% get RF DATA 
% Open the file for reading
fid = fopen('trus_p.txt', 'r');

% Initialize variables to store the data
data = zeros(0, 2);
idx = 1;

% Read each line of the file and process it
tline = fgetl(fid);
while ischar(tline)
    % Split the line into tokens separated by whitespace
    tokens = strsplit(tline);
    
    % Check if the line contains "bad"
    if strcmp(tokens{1}, 'bad')
        % If it does, record zero in the data array
        data(idx, :) = [0 0];
    else
        % If it doesn't, record the two numbers in the data array
        data(idx, :) = [str2double(tokens{1}) str2double(tokens{2})];
    end
    
    % Increment the index counter
    idx = idx + 1;
    
    % Read the next line of the file
    tline = fgetl(fid);
end

% Close the file
fclose(fid);


%% remove the bad points from B and RFdata
% find the position of the bad points
% Find the row indices where the first column is zero
bad_indices = find(data(:, 1) == 0);

data(bad_indices,:)=[];



%% define the test parameters(size of the RF data).
sample_frequency=6.6e6;
depth_mm=29;
width_mm=60;
RF=zeros(1648,256); %get the RF data size from RP read\run me


%% calculte trus p 
for i=1:size(data,1)
x(i)=(data(i,1)-(size(RF,2)/2))*(width_mm/size(RF,2)); % Find x relative to center of image

%to get trus data, since the RF data and the actuall image is upside down,
%need to flip the y coordinate first ??? may not need
% y(i)=size(RF,1)-data(i,2)+1;
y(i)=data(i,2)*(depth_mm/size(RF,1)); %  

%y1(i)=data(i,2)*(1/sample_frequency)*1500/2*1000; %学长方法？？
p(i,:)=[x(i) y(i)];
end
trus_p=[p  zeros(size(x))']';

 
%% Helper functions

% Translational error between two 4x4 frames
function error=tranerror(X1, X2)
    error=norm(X1(1:3,4)-X2(1:3,4));
end

% Rotational error between two frames
function error=roterror(X1,X2)
    error=norm(so3_vec(logm((X1(1:3,1:3)'*X2(1:3,1:3)))));
end

%Function to vectorize or hat an element in so(3)
function g = so3_vec(X)
    if (size(X,2)==3)
        %If input is skew-sym change to vector
        g = [-X(2,3); X(1,3); -X(1,2)];
    else
        %If input is vector change to skew-sym
        g = [0      -X(3)	 X(2)
             X(3)    0      -X(1)
            -X(2)    X(1)    0   ];
    end
end

%Function to vectorize or hat an element of se(3)
function g = se3_vec(X)
    if (size(X,2)==4)
        %If input is skew-sym change to vector
        g = [-X(2,3); X(1,3); -X(1,2); X(1,4); X(2,4); X(3,4)];
    else
        %If input is vector change to skew-sym
        g = [0      -X(3)	 X(2)	 X(4)
             X(3)    0      -X(1)    X(5)
            -X(2)    X(1)    0       X(6)
            0        0       0       0   ];
    end
end
