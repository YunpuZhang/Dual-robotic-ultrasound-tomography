clear;clc
% Load the two point clouds
% cloud1 = pcread('points_in_robot_baseCloud.pcd');
% cloud2 = pcread('points_in_trusCloud.pcd');

cloud1 = pcread('A.pcd');
cloud2 = pcread('B.pcd');


% Create point cloud objects
ptCloud1 = pointCloud(cloud1.Location);
ptCloud2 = pointCloud(cloud2.Location);

% Set ICP parameters
maxIterations = 1000000;
tolerance = [0.0001 0.001];
initTform = eye(4);

% Register the point clouds using ICP
[tform, rmse] = pcregistericp(ptCloud2,ptCloud1, 'MaxIterations', maxIterations, 'Tolerance', tolerance);

transformation=[tform.R tform.Translation';[0 0 0 1]];
%this transformation is from 1 to 2.

% Transform point cloud 2 to align with point cloud 1
ptCloudAligned = pctransform(ptCloud2, tform);

% Visualize the point clouds
figure
subplot(1, 2, 1)
pcshow(ptCloud1, 'MarkerSize', 130);
title('Point Cloud 1')
subplot(1, 2, 2)
pcshow(ptCloudAligned,  'MarkerSize', 130);
title('Point Cloud 2 Aligned with Point Cloud 1')
disp(tform)