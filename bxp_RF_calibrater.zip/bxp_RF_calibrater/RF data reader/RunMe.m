% The following script reads and displays the RF signals acquired using
% Sonix ultrasound machine
%
% Copyright Ultrasonix Medical corporation - Analogic Ultrasound Group
% Author: Reza Zahiri Azar - Jan 2014

close all;
clear;
clc;

% add the path for the RP reader
addpath('C:\Users\Zhenghao Li\Desktop\2nd_xueqi\cis2\calibration_code\bxp_RF_calibrater\RF data reader\RPread\RPread');

% reading RF data
path = 'data\';
filename ='19-24-52.rf';

n = 1;     % number of frames
[RFframes, header] = RPread( [path, filename], n); 

% displaying RF images
figure; colormap(gray);
for i = 1:n
    RFframe = RFframes(:,:,i);

    subplot(2, 2, 1 );
    imagesc( RFframe );
    axis square; title('RF image'); ylabel('Samples');
    xlabel('Scan Lines');

    subplot(2, 2, 2 )
    imagesc( 20*log10( abs(hilbert(RFframe) ) ) , [20 90]); 
    title('B image'); ylabel('Samples'); xlabel('Scan Lines');
    axis square;

    subplot(2, 1, 2 )
    lnInd = 130;    % line of interest
    plot( RFframe(:,lnInd)  ); 
    title('RF line'); xlabel('Samples'); ylabel('Amplitude');
    axis tight;
end

RFframe=RFframe(100:1549,:);
value=max(max(RFframe))
[m,n] = find(RFframe==max(max(RFframe)));

diff_m=abs(m(1)-m(end)); %vertical length of point cloud 
diff_n=abs(n(1)-n(end));

error_range=diff_n*1500/40e6*1000

% if diff_m+diff_n<100, consider point cloud useful
x=median(n)
y=median(m)+100

